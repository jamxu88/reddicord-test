# Reddicord
Reddit in Discord- upvote and downvote the posts of other users!
